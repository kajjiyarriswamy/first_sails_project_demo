package com.example.SpringBootBackendServices.model;

import jakarta.persistence.*;

import java.sql.Timestamp;

@Entity
@Table(name="user_profile")
public class UserProfile {

    @Id
    @GeneratedValue
    @Column(name="user_profile_id")
    private Integer userProfileId;
    @Column(name="firstName")
    private String firstName;
    @Column(name="middle_name")
    private String middleName;
    @Column(name="last_name")
    private String lastName;
    @Column(name="user_email")
    private String userEmail;
    @Column(name="address")
    private String address;
    @Column(name="phone_number")
    private String phoneNumber;

    private Timestamp createdDate;

    private String createdUserI;

    private Timestamp lastUpdateDate;

    private String lastUpdatedUserI;

    public Integer getUserProfileId() {
        return userProfileId;
    }

    public void setUserProfileId(Integer userProfileId) {
        this.userProfileId = userProfileId;
    }

    public String getFirstName() {
        return firstName;
    }

    public void setFirstName(String firstName) {
        this.firstName = firstName;
    }

    public String getMiddleName() {
        return middleName;
    }

    public void setMiddleName(String middleName) {
        this.middleName = middleName;
    }

    public String getLastName() {
        return lastName;
    }

    public void setLastName(String lastName) {
        this.lastName = lastName;
    }

    public String getUserEmail() {
        return userEmail;
    }

    public void setUserEmail(String userEmail) {
        this.userEmail = userEmail;
    }

    public String getAddress() {
        return address;
    }

    public void setAddress(String address) {
        this.address = address;
    }

    public String getPhoneNumber() {
        return phoneNumber;
    }

    public void setPhoneNumber(String phoneNumber) {
        this.phoneNumber = phoneNumber;
    }

    public Timestamp getCreatedDate() {
        return createdDate;
    }

    public void setCreatedDate(Timestamp createdDate) {
        this.createdDate = createdDate;
    }

    public String getCreatedUserI() {
        return createdUserI;
    }

    public void setCreatedUserI(String createdUserI) {
        this.createdUserI = createdUserI;
    }

    public Timestamp getLastUpdateDate() {
        return lastUpdateDate;
    }

    public void setLastUpdateDate(Timestamp lastUpdateDate) {
        this.lastUpdateDate = lastUpdateDate;
    }

    public String getLastUpdatedUserI() {
        return lastUpdatedUserI;
    }

    public void setLastUpdatedUserI(String lastUpdatedUserI) {
        this.lastUpdatedUserI = lastUpdatedUserI;
    }
}
