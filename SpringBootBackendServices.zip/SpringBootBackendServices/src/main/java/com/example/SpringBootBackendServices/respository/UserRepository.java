package com.example.SpringBootBackendServices.respository;

import com.example.SpringBootBackendServices.model.UserProfile;
import org.springframework.data.jpa.repository.JpaRepository;

public interface UserRepository extends JpaRepository<UserProfile, Integer> {
}
