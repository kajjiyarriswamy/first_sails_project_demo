package com.example.SpringBootBackendServices.controller;

import com.example.SpringBootBackendServices.service.UserService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.HttpRequestMethodNotSupportedException;
import org.springframework.web.bind.annotation.*;
import com.example.SpringBootBackendServices.model.UserProfile;

import java.util.List;

@RestController
public class UserController {

    @Autowired
    private UserService userService;

    @PostMapping("/insertUserData")
    public ResponseEntity<?> insertUserData(@RequestBody  UserProfile userProfile) {
        if (userProfile != null) {
    UserProfile dbUserData= userService.insertuserData(userProfile);
         return new ResponseEntity(dbUserData,HttpStatus.OK);
        }
        return new ResponseEntity("Oops something went wrong", HttpStatus.OK);
    }


    @GetMapping("/getAllUsers")
    public ResponseEntity getAllUsers(){
        List<UserProfile> list= userService.getAllUsers();
        return new ResponseEntity(list,HttpStatus.OK);
    }

    @PutMapping("/updateUser")
    public ResponseEntity updateUser(@RequestBody  UserProfile userProfile) throws HttpRequestMethodNotSupportedException {
        UserProfile dbUser= userService.updateUserProfile(userProfile);
        if(dbUser!=null) {
            return new ResponseEntity(dbUser, HttpStatus.OK);
        }else{
            return new ResponseEntity("No records found with user",HttpStatus.OK);
        }
    }
}
