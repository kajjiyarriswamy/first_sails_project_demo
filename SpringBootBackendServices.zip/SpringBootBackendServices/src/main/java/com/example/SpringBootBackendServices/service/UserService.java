package com.example.SpringBootBackendServices.service;

import ch.qos.logback.classic.Logger;
import com.example.SpringBootBackendServices.model.UserProfile;
import com.example.SpringBootBackendServices.respository.UserRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.sql.Timestamp;
import java.util.Date;
import java.util.List;

@Service
public class UserService {

@Autowired
    private UserRepository userRepository;


    public UserProfile insertuserData(UserProfile userProfiler){
        try {
            userProfiler.setCreatedUserI(userProfiler.getUserEmail());
            userProfiler.setCreatedDate(new Timestamp(new Date().getTime()));
            UserProfile userProfile = userRepository.save(userProfiler);
            if (userProfile != null) {
                return userProfile;
            } else {
                return null;
            }
        }catch (Exception e){
            System.out.println("Exception occurred during insertion of user data:"+e.getMessage());
        }
        return null;
    }


    public List<UserProfile> getAllUsers(){
        return  userRepository.findAll();
    }

    public UserProfile updateUserProfile(UserProfile userProfile){
        UserProfile dbUserProfile=userRepository.getById(userProfile.getUserProfileId());
        if(dbUserProfile!=null){
            dbUserProfile.setFirstName(userProfile.getFirstName());
            dbUserProfile.setLastName(userProfile.getLastName());
            dbUserProfile.setUserEmail(userProfile.getUserEmail());
            dbUserProfile.setAddress(userProfile.getAddress());
            dbUserProfile.setPhoneNumber(userProfile.getPhoneNumber());
            dbUserProfile.setLastUpdatedUserI(userProfile.getUserEmail());
            dbUserProfile.setLastUpdateDate(new Timestamp(new Date().getTime()));
            return userRepository.save(dbUserProfile);
        }else{
            return null;
        }
    }
}
