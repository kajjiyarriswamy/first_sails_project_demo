package com.example.SpringBootBackendServices;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringBootBackendServicesApplication {

	public static void main(String[] args) {
		SpringApplication.run(SpringBootBackendServicesApplication.class, args);
	}

}
