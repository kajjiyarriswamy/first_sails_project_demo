package com.example.SpringBootBackendServices;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringBootBackendServicesApplicationTests {

	@Test
	void contextLoads() {
	}

}
